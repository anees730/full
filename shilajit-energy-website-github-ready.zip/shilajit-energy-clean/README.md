# Shilajit Energy Drink Website

A complete full-stack web application for Shilajit Energy Drinks featuring a modern frontend with a robust Flask backend.

## 🚀 Features

### Frontend
- **Responsive Design**: Mobile-first approach with beautiful UI/UX
- **Product Showcase**: Dynamic product display with images and pricing
- **Shopping Cart**: Add to cart functionality with session management
- **Contact Form**: Customer inquiry system with form validation
- **Newsletter Subscription**: Email subscription with confirmation
- **Modern Animations**: Smooth transitions and interactive elements

### Backend
- **RESTful API**: Clean API endpoints for all functionality
- **Database Management**: SQLite database with proper schema design
- **Session Management**: Cart persistence across user sessions
- **CORS Support**: Cross-origin resource sharing for frontend integration
- **Data Validation**: Input validation and error handling
- **Sample Data**: Pre-populated with product catalog

## 🛠️ Technology Stack

### Frontend
- HTML5, CSS3, JavaScript (ES6+)
- Responsive Grid Layout
- CSS Animations and Transitions
- Fetch API for backend communication

### Backend
- **Python 3.11+**
- **Flask** - Web framework
- **SQLAlchemy** - ORM for database operations
- **Flask-CORS** - Cross-origin resource sharing
- **SQLite** - Database (easily replaceable with PostgreSQL/MySQL)

## 📁 Project Structure

```
shilajit-energy-website-complete/
├── src/
│   ├── main.py                 # Flask application entry point
│   ├── database.py             # Database configuration
│   ├── models/                 # Database models
│   │   ├── user.py
│   │   ├── product.py
│   │   ├── cart.py
│   │   ├── contact.py
│   │   └── newsletter.py
│   ├── routes/                 # API route handlers
│   │   ├── user.py
│   │   ├── products.py
│   │   ├── cart.py
│   │   ├── contact.py
│   │   └── newsletter.py
│   ├── static/                 # Frontend files
│   │   └── index.html          # Main website file
│   └── database/               # SQLite database files
├── venv/                       # Python virtual environment
├── requirements.txt            # Python dependencies
├── README.md                   # This file
└── .gitignore                  # Git ignore rules
```

## 🚀 Quick Start

### Prerequisites
- Python 3.11 or higher
- pip (Python package manager)

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd shilajit-energy-website-complete
   ```

2. **Create and activate virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python src/main.py
   ```

5. **Access the website**
   Open your browser and navigate to: `http://localhost:5000`

## 🔧 Configuration

### Environment Variables
The application uses the following default configurations:
- **Database**: SQLite (stored in `src/database/app.db`)
- **Port**: 5000
- **Debug Mode**: Enabled (disable for production)

### Database Setup
The database is automatically created when you first run the application. Sample products are pre-loaded for demonstration.

## 📊 API Endpoints

### Products
- `GET /api/products` - Get all active products
- `GET /api/products/<id>` - Get specific product details

### Shopping Cart
- `POST /api/cart/add` - Add item to cart
- `GET /api/cart` - Get cart contents
- `DELETE /api/cart/remove/<id>` - Remove item from cart

### Contact & Newsletter
- `POST /api/contact` - Submit contact form
- `POST /api/subscribe` - Subscribe to newsletter

### User Management
- `POST /api/register` - User registration
- `POST /api/login` - User login
- `GET /api/profile` - Get user profile

## 🎨 Customization

### Adding New Products
1. Access the Flask shell or create a script
2. Use the Product model to add new items:
   ```python
   from src.models.product import Product
   from src.database import db
   
   new_product = Product(
       name="New Flavor",
       description="Description here",
       price=36.00,
       image_url="https://example.com/image.jpg",
       category="Energy Drink",
       stock_quantity=100
   )
   db.session.add(new_product)
   db.session.commit()
   ```

### Styling Changes
- Edit `src/static/index.html` for layout and styling changes
- CSS is embedded in the HTML file for easy modification
- JavaScript functionality is also embedded for simplicity

## 🚀 Deployment

### Local Development
The application is ready to run locally with the quick start instructions above.

### Production Deployment

#### Option 1: Traditional Server
1. Set up a Linux server (Ubuntu/CentOS)
2. Install Python 3.11+, nginx, and gunicorn
3. Clone the repository
4. Set up virtual environment and install dependencies
5. Configure nginx as reverse proxy
6. Use gunicorn to serve the Flask application

#### Option 2: Cloud Platforms
- **Heroku**: Add `Procfile` and deploy directly
- **DigitalOcean App Platform**: Use the built-in Python buildpack
- **AWS Elastic Beanstalk**: Deploy as Python application
- **Google Cloud Run**: Containerize and deploy

#### Option 3: Docker
Create a `Dockerfile`:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "src/main.py"]
```

## 🧪 Testing

The application has been thoroughly tested with:
- ✅ Product display and loading
- ✅ Add to cart functionality
- ✅ Contact form submission
- ✅ Newsletter subscription
- ✅ API endpoint responses
- ✅ Database operations
- ✅ Frontend-backend integration

## 🔒 Security Considerations

For production deployment, consider:
- Change the Flask secret key
- Use environment variables for sensitive data
- Implement rate limiting
- Add input sanitization
- Use HTTPS
- Implement proper authentication
- Add CSRF protection

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

For support and questions:
- Email: info@shilajitenergydrinks.com
- Phone: (800) 674-8302

## 🙏 Acknowledgments

- Built with Flask and modern web technologies
- Responsive design inspired by modern e-commerce sites
- Product images and content for demonstration purposes

---

**Made with ❤️ for natural energy enthusiasts**

