# Deployment Guide

This guide provides step-by-step instructions for deploying the Shilajit Energy Drink website to various platforms.

## 🚀 Quick Deploy Options

### 1. Heroku Deployment

#### Prerequisites
- Heroku account
- Heroku CLI installed

#### Steps
1. **Create Procfile**
   ```bash
   echo "web: python src/main.py" > Procfile
   ```

2. **Update main.py for Heroku**
   Add this to the end of `src/main.py`:
   ```python
   if __name__ == '__main__':
       port = int(os.environ.get('PORT', 5000))
       app.run(host='0.0.0.0', port=port, debug=False)
   ```

3. **Deploy**
   ```bash
   heroku create your-app-name
   git add .
   git commit -m "Initial deployment"
   git push heroku main
   ```

### 2. DigitalOcean App Platform

#### Steps
1. **Connect GitHub Repository**
   - Go to DigitalOcean App Platform
   - Connect your GitHub repository
   - Select the main branch

2. **Configure Build Settings**
   - Build Command: `pip install -r requirements.txt`
   - Run Command: `python src/main.py`
   - Environment: Python 3.11

3. **Deploy**
   - Click "Create App"
   - Wait for deployment to complete

### 3. Railway Deployment

#### Steps
1. **Connect Repository**
   - Go to Railway.app
   - Connect your GitHub repository

2. **Configure Environment**
   - Railway auto-detects Python
   - Set start command: `python src/main.py`

3. **Deploy**
   - Automatic deployment on push

### 4. Render Deployment

#### Steps
1. **Create Web Service**
   - Go to Render.com
   - Connect GitHub repository

2. **Configure Service**
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python src/main.py`
   - Environment: Python 3

3. **Deploy**
   - Click "Create Web Service"

## 🐳 Docker Deployment

### Create Dockerfile
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Copy requirements first for better caching
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create database directory
RUN mkdir -p src/database

# Expose port
EXPOSE 5000

# Set environment variables
ENV FLASK_APP=src/main.py
ENV FLASK_ENV=production

# Run the application
CMD ["python", "src/main.py"]
```

### Build and Run
```bash
# Build image
docker build -t shilajit-energy-website .

# Run container
docker run -p 5000:5000 shilajit-energy-website
```

### Docker Compose
Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  web:
    build: .
    ports:
      - "5000:5000"
    volumes:
      - ./src/database:/app/src/database
    environment:
      - FLASK_ENV=production
```

Run with:
```bash
docker-compose up -d
```

## 🖥️ VPS/Server Deployment

### Ubuntu Server Setup

#### 1. Server Preparation
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and dependencies
sudo apt install python3.11 python3.11-venv python3-pip nginx -y

# Install Git
sudo apt install git -y
```

#### 2. Application Setup
```bash
# Clone repository
git clone <your-repo-url>
cd shilajit-energy-website-complete

# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install Gunicorn
pip install gunicorn
```

#### 3. Create Gunicorn Service
Create `/etc/systemd/system/shilajit-energy.service`:
```ini
[Unit]
Description=Shilajit Energy Website
After=network.target

[Service]
User=ubuntu
Group=www-data
WorkingDirectory=/home/ubuntu/shilajit-energy-website-complete
Environment="PATH=/home/ubuntu/shilajit-energy-website-complete/venv/bin"
ExecStart=/home/ubuntu/shilajit-energy-website-complete/venv/bin/gunicorn --workers 3 --bind unix:shilajit-energy.sock -m 007 src.main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

#### 4. Configure Nginx
Create `/etc/nginx/sites-available/shilajit-energy`:
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        include proxy_params;
        proxy_pass http://unix:/home/ubuntu/shilajit-energy-website-complete/shilajit-energy.sock;
    }

    location /static {
        alias /home/ubuntu/shilajit-energy-website-complete/src/static;
    }
}
```

#### 5. Enable and Start Services
```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/shilajit-energy /etc/nginx/sites-enabled

# Test nginx configuration
sudo nginx -t

# Start services
sudo systemctl start shilajit-energy
sudo systemctl enable shilajit-energy
sudo systemctl restart nginx
```

## 🔒 SSL Certificate (Let's Encrypt)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Get certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

## 🌍 Environment Variables for Production

Create `.env` file:
```env
FLASK_ENV=production
SECRET_KEY=your-super-secret-key-here
DATABASE_URL=sqlite:///src/database/app.db
CORS_ORIGINS=https://your-domain.com
```

Update `src/main.py` to use environment variables:
```python
import os
from dotenv import load_dotenv

load_dotenv()

app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'fallback-secret-key')
```

## 📊 Monitoring and Maintenance

### Log Monitoring
```bash
# View application logs
sudo journalctl -u shilajit-energy -f

# View nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### Database Backup
```bash
# Create backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
cp /home/ubuntu/shilajit-energy-website-complete/src/database/app.db \
   /home/ubuntu/backups/app_backup_$DATE.db

# Add to crontab for daily backups
0 2 * * * /home/ubuntu/backup_db.sh
```

### Updates
```bash
# Pull latest changes
git pull origin main

# Restart application
sudo systemctl restart shilajit-energy
```

## 🚨 Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   sudo lsof -i :5000
   sudo kill -9 <PID>
   ```

2. **Permission Denied**
   ```bash
   sudo chown -R ubuntu:www-data /home/ubuntu/shilajit-energy-website-complete
   sudo chmod -R 755 /home/ubuntu/shilajit-energy-website-complete
   ```

3. **Database Issues**
   ```bash
   # Reset database
   rm src/database/app.db
   python src/main.py  # Will recreate with sample data
   ```

4. **Nginx Configuration Test**
   ```bash
   sudo nginx -t
   sudo systemctl reload nginx
   ```

## 📈 Performance Optimization

### Production Settings
- Use a production WSGI server (Gunicorn/uWSGI)
- Enable gzip compression in Nginx
- Set up caching headers
- Use a CDN for static assets
- Monitor with tools like New Relic or DataDog

### Database Optimization
- Consider PostgreSQL for production
- Implement connection pooling
- Add database indexes for frequently queried fields
- Regular database maintenance

---

Choose the deployment method that best fits your needs and infrastructure requirements.

