import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.database import db

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Import models after db initialization
from src.models.user import User
from src.models.product import Product
from src.models.cart import CartItem
from src.models.contact import ContactMessage
from src.models.newsletter import NewsletterSubscription

# Import routes
from src.routes.user import user_bp
from src.routes.products import products_bp
from src.routes.cart import cart_bp
from src.routes.contact import contact_bp
from src.routes.newsletter import newsletter_bp

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(products_bp, url_prefix='/api')
app.register_blueprint(cart_bp, url_prefix='/api')
app.register_blueprint(contact_bp, url_prefix='/api')
app.register_blueprint(newsletter_bp, url_prefix='/api')

with app.app_context():
    db.create_all()
    
    # Add sample products if they don't exist
    if Product.query.count() == 0:
        sample_products = [
            Product(
                name="Mango • 12 Pack",
                description="Tropical mango flavor with pure Shilajit extract",
                price=36.00,
                image_url="https://shilajitenergydrinks.com/cdn/shop/files/12ozsleek-Shilajit_mango_final.png?v=1723237258",
                category="Energy Drink",
                stock_quantity=100,
                is_active=True
            ),
            Product(
                name="Orange Peach • 12 Pack",
                description="Refreshing citrus peach blend with natural energy",
                price=36.00,
                image_url="https://i5.walmartimages.com/asr/09b38e1e-8e94-4f73-9d31-f381a8757dd0.a7dbf3c6af556583aafd50cbec0252a8.jpeg?odnHeight=768&odnWidth=768&odnBg=FFFFFF",
                category="Energy Drink",
                stock_quantity=100,
                is_active=True
            ),
            Product(
                name="Mixed Berry • 12 Pack",
                description="Antioxidant-rich berry blend for sustained energy",
                price=36.00,
                image_url="https://shilajitenergydrinks.com/cdn/shop/files/12ozsleek-Shilajitenergymixedberryfront_813ec292-e4dd-4087-83bc-6f0e5e27e646.png?v=1723580232&width=1920",
                category="Energy Drink",
                stock_quantity=100,
                is_active=True
            ),
            Product(
                name="Strawberry • 12 Pack",
                description="Sweet strawberry flavor with natural minerals",
                price=36.00,
                image_url="https://m.media-amazon.com/images/I/51pFNeo7-ZL._UF1000,1000_QL80_.jpg",
                category="Energy Drink",
                stock_quantity=100,
                is_active=True
            ),
            Product(
                name="Strawberry Pallet",
                description="Bulk strawberry flavor for distributors",
                price=3744.00,
                image_url="https://i.etsystatic.com/58990172/r/il/41c85a/6854867101/il_fullxfull.6854867101_t9dj.jpg",
                category="Wholesale",
                stock_quantity=50,
                is_active=True
            )
        ]
        
        for product in sample_products:
            db.session.add(product)
        
        db.session.commit()
        print("Sample products added to database")

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    """Serve the frontend application"""
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') != 'production'
    app.run(host='0.0.0.0', port=port, debug=debug)
