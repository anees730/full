from flask import Blueprint, jsonify, request
from src.models.newsletter import NewsletterSubscription
from src.database import db
import re

newsletter_bp = Blueprint('newsletter', __name__)

def validate_email(email):
    """Simple email validation"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

@newsletter_bp.route('/subscribe', methods=['POST'])
def subscribe():
    """Subscribe to newsletter"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        email = data.get('email', '').strip().lower()
        
        # Validation
        if not email:
            return jsonify({
                'success': False,
                'error': 'Email is required'
            }), 400
        
        if not validate_email(email):
            return jsonify({
                'success': False,
                'error': 'Invalid email format'
            }), 400
        
        if len(email) > 100:
            return jsonify({
                'success': False,
                'error': 'Email must be less than 100 characters'
            }), 400
        
        # Check if email already exists
        existing_subscription = NewsletterSubscription.query.filter_by(email=email).first()
        
        if existing_subscription:
            if existing_subscription.is_active:
                return jsonify({
                    'success': False,
                    'error': 'Email is already subscribed to our newsletter'
                }), 400
            else:
                # Reactivate subscription
                existing_subscription.is_active = True
                db.session.commit()
                return jsonify({
                    'success': True,
                    'message': 'Welcome back! Your subscription has been reactivated.'
                }), 200
        
        # Create new subscription
        subscription = NewsletterSubscription(email=email)
        db.session.add(subscription)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Thank you for subscribing to our newsletter!'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@newsletter_bp.route('/unsubscribe', methods=['POST'])
def unsubscribe():
    """Unsubscribe from newsletter"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        email = data.get('email', '').strip().lower()
        
        if not email:
            return jsonify({
                'success': False,
                'error': 'Email is required'
            }), 400
        
        subscription = NewsletterSubscription.query.filter_by(email=email).first()
        
        if not subscription:
            return jsonify({
                'success': False,
                'error': 'Email not found in our newsletter list'
            }), 404
        
        subscription.is_active = False
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'You have been unsubscribed from our newsletter.'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

