from flask import Blueprint, jsonify, request
from src.models.cart import CartItem
from src.database import db
from src.models.product import Product
from src.database import db
import uuid

cart_bp = Blueprint('cart', __name__)

@cart_bp.route('/cart/add', methods=['POST'])
def add_to_cart():
    """Add product to cart"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        product_id = data.get('product_id')
        quantity = data.get('quantity', 1)
        session_id = data.get('session_id')
        
        if not product_id:
            return jsonify({
                'success': False,
                'error': 'Product ID is required'
            }), 400
        
        # Generate session ID if not provided
        if not session_id:
            session_id = str(uuid.uuid4())
        
        # Check if product exists
        product = Product.query.get(product_id)
        if not product or not product.is_active:
            return jsonify({
                'success': False,
                'error': 'Product not found or not available'
            }), 404
        
        # Check if item already exists in cart
        existing_item = CartItem.query.filter_by(
            session_id=session_id,
            product_id=product_id
        ).first()
        
        if existing_item:
            existing_item.quantity += quantity
        else:
            cart_item = CartItem(
                session_id=session_id,
                product_id=product_id,
                quantity=quantity
            )
            db.session.add(cart_item)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Product added to cart',
            'session_id': session_id
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/<session_id>', methods=['GET'])
def get_cart(session_id):
    """Get cart items for session"""
    try:
        cart_items = CartItem.query.filter_by(session_id=session_id).all()
        
        total_amount = 0
        items = []
        
        for item in cart_items:
            item_dict = item.to_dict()
            if item.product:
                item_total = float(item.product.price) * item.quantity
                item_dict['item_total'] = item_total
                total_amount += item_total
            items.append(item_dict)
        
        return jsonify({
            'success': True,
            'cart_items': items,
            'total_amount': total_amount,
            'item_count': len(items)
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/<session_id>/<int:item_id>', methods=['DELETE'])
def remove_from_cart(session_id, item_id):
    """Remove item from cart"""
    try:
        cart_item = CartItem.query.filter_by(
            id=item_id,
            session_id=session_id
        ).first()
        
        if not cart_item:
            return jsonify({
                'success': False,
                'error': 'Cart item not found'
            }), 404
        
        db.session.delete(cart_item)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Item removed from cart'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

