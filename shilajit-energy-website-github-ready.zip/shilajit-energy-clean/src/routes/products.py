from flask import Blueprint, jsonify, request
from src.models.product import Product
from src.database import db

products_bp = Blueprint('products', __name__)

@products_bp.route('/products', methods=['GET'])
def get_products():
    """Get all active products"""
    try:
        products = Product.query.filter_by(is_active=True).all()
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Get specific product details"""
    try:
        product = Product.query.get(product_id)
        if not product:
            return jsonify({
                'success': False,
                'error': 'Product not found'
            }), 404
        
        if not product.is_active:
            return jsonify({
                'success': False,
                'error': 'Product not available'
            }), 404
            
        return jsonify({
            'success': True,
            'product': product.to_dict()
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

